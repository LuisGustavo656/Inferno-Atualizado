<?php
session_start();
include '../includes/db.php';
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $preco = $_POST['preco'];
    $categoria = $_POST['categoria'];
    $tamanho = $_POST['tamanho'];
    $imagem = $_FILES['imagem']['name'];
    $target = "../uploads/" . basename($imagem);
    move_uploaded_file($_FILES['imagem']['tmp_name'], $target);
    $sql = "INSERT INTO produtos (nome, descricao, preco, categoria, tamanho, imagem) 
            VALUES ('$nome', '$descricao', $preco, '$categoria', '$tamanho', '$imagem')";
    $conn->query($sql);
    header('Location: produtos.php');
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Produto</title>
    <style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #f8f9fa;
    color: #333;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 20px;
}
h1 {
    color: #007bff;
    margin-bottom: 20px;
    text-align: center;
}
form {
    width: 90%;
    max-width: 600px;
    background: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}
form label {
    font-size: 14px;
    font-weight: bold;
    color: #555;
    display: block;
    margin-bottom: 5px;
}
form input[type="text"],
form input[type="number"],
form input[type="file"],
form textarea {
    width: 100%;
    padding: 10px;
    margin-bottom: 15px;
    border: 1px solid #ced4da;
    border-radius: 4px;
    font-size: 14px;
    color: #495057;
}
form input[type="text"]:focus,
form input[type="number"]:focus,
form input[type="file"]:focus,
form textarea:focus {
    border-color: #007bff;
    outline: none;
}
form button[type="submit"] {
    width: 100%;
    background-color: #007bff;
    color: #fff;
    border: none;
    padding: 10px;
    font-size: 16px;
    font-weight: bold;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s;
}
form button[type="submit"]:hover {
    background-color: #0056b3;
}
    </style>
</head>
<body>
    <h1>Adicionar Produto</h1>
    <form method="post" enctype="multipart/form-data">
        <label>Nome:</label>
        <input type="text" name="nome" required>
        <br>
        <label>Descrição:</label>
        <textarea name="descricao" required></textarea>
        <br>
        <label>Preço:</label>
        <input type="number" step="0.01" name="preco" required>
        <br>
        <label>Categoria:</label>
        <input type="text" name="categoria" required>
        <br>
        <label>Tamanho:</label>
        <input type="text" name="tamanho" required>
        <br>
        <label>Imagem:</label>
        <input type="file" name="imagem" required>
        <br>
        <button type="submit">Adicionar</button>
    </form>
</body>
</html>