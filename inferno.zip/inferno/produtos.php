<?php
include 'includes/db.php';
include 'includes/header.php';

$sql = "SELECT * FROM produtos";
$result = $conn->query($sql);

$sql_categories = "SELECT DISTINCT categoria FROM produtos";
$categories_result = $conn->query($sql_categories);
?>
<head>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        .produto {
            border: 1px solid #ccc;
            border-radius: 8px;
            padding: 15px;
            background-color: #f9f9f9;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease-in-out;
        }

        .produto:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .search-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .search-bar input {
            width: 70%;
        }

        .search-bar select {
            width: 25%;
        }
    </style>
</head>

<h1>Produtos</h1>

<div class="search-bar mb-4">
    <form method="GET" action="produtos.php" class="d-flex">
        <input type="text" name="search" placeholder="Pesquisar produto" class="form-control" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">

        <select name="categoria" class="form-select ms-2">
            <option value="">Selecione a categoria</option>
            <?php while ($category = $categories_result->fetch_assoc()) : ?>
                <option value="<?php echo $category['categoria']; ?>" <?php echo isset($_GET['categoria']) && $_GET['categoria'] == $category['categoria'] ? 'selected' : ''; ?>>
                    <?php echo $category['categoria']; ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button type="submit" class="btn btn-primary ms-2">Buscar</button>
    </form>
</div>

<div class="container">
    <div class="row">
        <?php
        $search = isset($_GET['search']) ? $_GET['search'] : '';
        $categoria = isset($_GET['categoria']) ? $_GET['categoria'] : '';

        $sql = "SELECT * FROM produtos WHERE nome LIKE '%$search%'";

        if ($categoria) {
            $sql .= " AND categoria = '$categoria'";
        }

        $result = $conn->query($sql);

        while ($produto = $result->fetch_assoc()) :
        ?>
            <div class="col-md-3 col-sm-6 col-12 mb-4">
                <div class="produto">
                    <img src="uploads/<?php echo $produto['imagem']; ?>" alt="<?php echo $produto['nome']; ?>" class="img-fluid">
                    <h2><?php echo $produto['nome']; ?></h2>
                    <p><?php echo $produto['descricao']; ?></p>
                    <p>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></p>
                    <form method="POST" action="carrinho.php" style="display:contents;">
                        <input type="hidden" name="produto_id" value="<?php echo $produto['id']; ?>">
                        <label for="tamanho">Tamanho:</label>
                        <select name="tamanho" id="tamanho" required class="form-select">
                            <option value="P">P</option>
                            <option value="M">M</option>
                            <option value="G">G</option>
                            <option value="GG">GG</option>
                        </select>
                        <button type="submit" name="add_to_cart" class="btn btn-primary mt-2">Adicionar ao Carrinho</button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<footer>
    <p>&copy; 2024 Loja de Roupas. Todos os direitos reservados.</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pzjw8f+ua7Kw1TIq0pXh7S3QybM8w0+3FfNzG3bEydtOdp6Exybhmhm7gIpY5dZn" crossorigin="anonymous"></script>
            