<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);
    $mensagem = htmlspecialchars($_POST['mensagem']);
    $to = "your_email@example.com";
    $subject = "Contato de $nome";
    $body = "Nome: $nome\nE-mail: $email\n\nMensagem:\n$mensagem";
    $headers = "From: $email";

    if (mail($to, $subject, $body, $headers)) {
        echo "Mensagem enviada com sucesso!";
    } else {
        echo "Erro ao enviar a mensagem.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato - Loja de Roupas</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <main>
        <h1>Entre em Contato Conosco</h1>
        <p>
            Tem dúvidas, sugestões ou precisa de ajuda? Entre em contato conosco preenchendo o formulário abaixo ou 
            utilizando nossos canais de atendimento. Estamos aqui para ajudar!
        </p>

        <!-- Formulário de Contato -->
        <form action="enviar_contato.php" method="post">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" placeholder="Seu nome completo" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" placeholder="Seu e-mail" required>

            <label for="mensagem">Mensagem:</label>
            <textarea id="mensagem" name="mensagem" rows="5" placeholder="Escreva sua mensagem aqui" required></textarea>

            <button type="submit">Enviar</button>
        </form>

        <!-- Informações de Contato -->
        <section>
            <h2>Outras formas de contato</h2>
            <p><strong>E-mail:</strong> contato@lojaderoupas.com</p>
            <p><strong>Telefone:</strong> (11) 98765-4321</p>
            <p><strong>Endereço:</strong> Rua das Flores, 123 - São Paulo, SP</p>
        </section>
    </main>

    <?php include 'includes/footer.php'; ?> 
</body>
</html>
