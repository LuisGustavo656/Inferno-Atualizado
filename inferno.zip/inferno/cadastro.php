<?php
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $senha_confirm = $_POST['senha_confirm'];
    if ($senha !== $senha_confirm) {
        $erro = "As senhas não coincidem!";
    } else {
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $query = "INSERT INTO usuarios (nome, email, senha, tipo_usuario) VALUES (?, ?, ?, 'usuario')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sss", $nome, $email, $senha_hash);

        if ($stmt->execute()) {
            echo "<p class='success'>Cadastro realizado com sucesso! <a href='login.php'>Clique aqui para fazer login</a>.</p>";
        } else {
            $erro = "Erro ao cadastrar usuário.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <style>
        body {
    background-color: #f8f9fa;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}
.auth-container .success-link {
    display: block;
    margin-top: 10px;
    font-size: 14px;
    text-align: center;
}

.auth-container .success-link a {
    color: #007bff;
    text-decoration: none;
    transition: color 0.3s ease;
}

.auth-container .success-link a:hover {
    color: #0056b3;
}
        </style>
    <link rel="stylesheet" href="css/style.css"> 
</head>
<body>
    <div class="auth-container">
        <h1>Cadastro</h1>
        <?php if (isset($erro)) echo "<p class='error'>$erro</p>"; ?>
        <?php if (isset($sucesso)) echo "<p class='success'>$sucesso</p>"; ?>
        <form method="POST" action="">
            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome" placeholder="Digite seu nome completo" required>

            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" placeholder="Digite seu e-mail" required>

            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>

            <label for="senha_confirm">Confirmar Senha</label>
            <input type="password" id="senha_confirm" name="senha_confirm" placeholder="Confirme sua senha" required>

            <button type="submit">Cadastrar</button>
        </form>

        <p class="signup-link">
            Já tem uma conta? <a href="login.php">Faça login aqui</a>.
        </p>
    </div>
</body>
</html>
